# Claude Code Handover — Nav Fix + Workout Log

## What's Changed

Two updates to the gnomeo-fit site:

1. **Nav bar fix** — `Layout.astro` now has the correct HTML structure (`nav-inner` wrapper div, `nav-link` classes) so the nav actually centers, aligns to max-width, and the active/hover states work properly. A "Log" link has also been added.

2. **Workout Log page** — A new password-protected log at `/log` that lets you record each workout with phase, day, rating, bodyweight, duration, and notes.

---

## Files to Copy Into the Repo

Replace or add these files in your local `gnomeo-fit` clone:

| File | Action |
|---|---|
| `src/layouts/Layout.astro` | **Replace** existing file |
| `src/components/WorkoutLog.jsx` | **Add** (new file) |
| `src/pages/log.astro` | **Add** (new file) |

---

## Steps

```bash
# 1. Copy the three files above into place

# 2. Verify the build locally
npm run build
npm run preview
# Visit http://localhost:4321/gnomeo-fit/log — should show passphrase setup screen

# 3. Commit and push
git add .
git commit -m "Fix nav centering, add workout log page"
git push
```

GitHub Actions deploys automatically. Live in ~2 minutes.

---

## How the Log Works

- **First visit:** prompts you to set a passphrase. The SHA-256 hash is stored in `localStorage` — not the passphrase itself.
- **Subsequent visits:** enter your passphrase to unlock.
- **Data:** all log entries are stored in `localStorage` under the key `gnomeo_fit_log`. They never leave the browser.
- **Reset:** there's a small "Reset passphrase" link on the login screen — use it only if you forget your passphrase. It clears all entries too.

### Security honest note
This is client-side only. Anyone with physical access to the browser and dev tools open can read `localStorage` directly. It's appropriate for a personal fitness log on your own device. Don't use this for anything sensitive.

---

## No Other Files Need Changing

`package.json`, `astro.config.mjs`, and the existing workout/nutrition components are untouched.
