# Claude Code Handover — Meal Plans + Shopping List

## What's New

Four new files, one updated file, one new data module.

| File | Action | Purpose |
|---|---|---|
| `src/data/meals.js` | **Add** (new) | Shared meal data — 40+ meal options with ingredients, macros, categories, and prices |
| `src/components/MealPlans.jsx` | **Add** (new) | Full meal planner with 4+ options per slot, plan builder sidebar, print |
| `src/components/ShoppingList.jsx` | **Add** (new) | 3-step shopping list builder — meal selection → store finder → organized printable list |
| `src/pages/meals.astro` | **Add** (new) | Astro wrapper for MealPlans |
| `src/pages/shopping.astro` | **Add** (new) | Astro wrapper for ShoppingList |
| `src/layouts/Layout.astro` | **Replace** | Updated nav with Meals + Shopping links, corrected nav centering |

---

## Steps

```bash
# 1. Drop all files into place (paths above are relative to repo root)

# 2. Install / confirm dependencies (no new packages needed)
npm install

# 3. Verify locally
npm run build
npm run preview
```

### Routes to verify
- `http://localhost:4321/gnomeo-fit/meals` — select meals for training and rest days, build plan, print
- `http://localhost:4321/gnomeo-fit/shopping` — 3-step: pick meals → find stores → review/print list
- `http://localhost:4321/gnomeo-fit/` — nav bar should show all 5 links, centered correctly

```bash
# 4. Commit and push
git add .
git commit -m "Add meal plans, shopping list, and shared meal data module"
git push
```

---

## Feature Overview

### Meal Plans (`/meals`)
- Training Day / Rest Day toggle
- 5 meal slots per day, 4 options each (40 total meal recipes)
- Each card: name, prep time, tags, macros, expandable instructions + ingredient list
- Sticky plan summary sidebar with running macro totals
- **Print button** — opens a clean print window (no nav, no dark theme) with full recipes and daily totals
- "Build Shopping List" button links to `/shopping`

### Shopping List (`/shopping`)
- **Step 1 — Select Meals:** same meal options as the Meals page, select one per slot per day type
- **Step 2 — Find Stores:**
  - ZIP code input + radius selector (5 / 10 / 15 / 25 / 35+ miles)
  - "Find Grocery Stores on Google Maps" button opens Maps search in new tab
  - Click to select up to 3 preferred stores from a curated list of major chains
  - Add any store not on the list manually
  - Preferred stores get their weekly ad pages linked throughout the list
- **Step 3 — Review List:**
  - Ingredients auto-aggregated from selected meals, organized by category (Produce, Protein, Dairy, Grains, Canned/Dry, Frozen, Pantry, Supplements)
  - Servings multiplier (1–7×) scales all quantities and prices
  - Per-item quantity adjuster (0.5× to 4×) for fine-tuning
  - Checkboxes for checking items off in-store
  - Bulk-buy tips (Costco / Sam's Club) shown inline per item — toggle on/off
  - Estimated total with clear disclaimer that prices are estimates
  - Weekly ad quick links for each preferred store
  - **Print button** — clean, readable printout organized by category with estimated prices

### Pricing Transparency
Prices are US market estimates (2025) built into the ingredient data. They're
ballpark figures, not live data — the disclaimer appears in the UI and on printed
lists. The "Check Weekly Ads" section links users directly to real-time deals
at their preferred stores, which is where actual savings are found.

---

## No Other Files Need Changing

`package.json`, `astro.config.mjs`, and existing workout/nutrition/log components are untouched.

---

## Troubleshooting

**"Cannot find module '../data/meals.js'"**
Verify the file is at exactly `src/data/meals.js`. The path is case-sensitive on Linux.

**Meal options not rendering**
The components use `client:load` in the Astro pages — this is already set correctly. If interactivity is missing, confirm the Astro pages include `client:load` on the component tag.

**Nav links wrapping / overflowing on mobile**
The nav uses `overflow-x: auto` with hidden scrollbar — links are horizontally scrollable on narrow screens. This is intentional.
